namespace SignalDesk.Tests;

public sealed class ScenarioRepositoryTests
{
    [Fact(Skip = "Implement when Data services are wired in Step 2")]
    public void Placeholder() { }
}
