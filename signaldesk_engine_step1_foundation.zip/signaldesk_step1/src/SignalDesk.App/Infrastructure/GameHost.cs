namespace SignalDesk.App.Infrastructure;

public sealed class GameHost
{
    public void Initialize()
    {
        // Wire services, paths, repositories, state factory, and scene manager.
        // Step 2: bootstrap raylib window and main loop here.
    }

    public void Run()
    {
        // Step 2: Raylib window loop -> Update/Draw current scene stack
    }
}
