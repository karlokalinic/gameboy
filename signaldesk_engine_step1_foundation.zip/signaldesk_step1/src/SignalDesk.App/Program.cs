using SignalDesk.App.Infrastructure;

namespace SignalDesk.App;

public static class Program
{
    public static void Main()
    {
        // STEP 2 IMPLEMENTATION NOTE:
        // Replace this placeholder with Raylib initialization and GameHost.Run().
        Console.WriteLine("SignalDesk.App skeleton ready. Implement raylib bootstrap in Step 2.");
        var host = new GameHost();
        host.Initialize();
    }
}
