namespace SignalDesk.UI.Windows;

public sealed class TaskbarPanel : WindowPanel
{
    public TaskbarPanel() : base("taskbar", "Taskbar") {}

    public override void Draw()
    {
        // Step 2: docked bottom bar showing window buttons and slot info
    }
}
