namespace SignalDesk.Tools.Panels;

public sealed class StateInspectorPanel
{
    // Dev-only panel (Hacker Mode) for mutating state at runtime.
    // Step 2: placeholder only.
}
