namespace SignalDesk.Tools.Panels;

public sealed class GraphDebugPanel
{
    // Visualizes nodes/edges, visited nodes, current node, and result paths.
    // Step 2: placeholder only.
}
